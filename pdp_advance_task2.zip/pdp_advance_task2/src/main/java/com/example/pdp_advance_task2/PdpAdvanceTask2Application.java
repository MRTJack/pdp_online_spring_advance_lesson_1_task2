package com.example.pdp_advance_task2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PdpAdvanceTask2Application {

    public static void main(String[] args) {
        SpringApplication.run(PdpAdvanceTask2Application.class, args);
    }

}

package com.example.pdp_advance_task2.task2.repo;

import com.example.pdp_advance_task2.task2.eninty.Category;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoryRepository extends JpaRepository<Category, Long> {

}

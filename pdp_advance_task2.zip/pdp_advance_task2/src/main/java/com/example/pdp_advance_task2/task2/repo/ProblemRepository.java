package com.example.pdp_advance_task2.task2.repo;

import com.example.pdp_advance_task2.task2.eninty.Category;
import com.example.pdp_advance_task2.task2.eninty.Problem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProblemRepository extends JpaRepository<Problem, Long> {
    List<Problem> findByCategory(Category category);
}

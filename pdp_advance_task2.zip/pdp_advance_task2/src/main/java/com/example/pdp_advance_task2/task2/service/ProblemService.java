package com.example.pdp_advance_task2.task2.service;

import com.example.pdp_advance_task2.task2.dto.ProblemDTO;
import com.example.pdp_advance_task2.task2.eninty.Category;
import com.example.pdp_advance_task2.task2.eninty.Problem;
import com.example.pdp_advance_task2.task2.repo.CategoryRepository;
import com.example.pdp_advance_task2.task2.repo.ProblemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProblemService {
    @Autowired
    private ProblemRepository problemRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Problem> getAllProblems() {
        return problemRepository.findAll();
    }

    public Problem getProblemById(Long id) {
        return problemRepository.findById(id).orElse(null);
    }

    public Problem createProblem(ProblemDTO problemDTO) {
        Problem problem = new Problem();
        problem.setName(problemDTO.getName());
        problem.setDescription(problemDTO.getDescription());

        Category category = categoryRepository.findById(problemDTO.getCategoryId()).orElse(null);
        problem.setCategory(category);

        return problemRepository.save(problem);
    }

    public Problem updateProblem(Long id, ProblemDTO problemDTO) {
        Problem existingProblem = problemRepository.findById(id).orElse(null);
        if (existingProblem != null) {
            existingProblem.setName(problemDTO.getName());
            existingProblem.setDescription(problemDTO.getDescription());

            Category category = categoryRepository.findById(problemDTO.getCategoryId()).orElse(null);
            existingProblem.setCategory(category);

            return problemRepository.save(existingProblem);
        }
        return null;
    }

    public void deleteProblem(Long id) {
        problemRepository.deleteById(id);
    }

    public List<Problem> getProblemsByCategory(Category category) {
        return problemRepository.findByCategory(category);
    }
}


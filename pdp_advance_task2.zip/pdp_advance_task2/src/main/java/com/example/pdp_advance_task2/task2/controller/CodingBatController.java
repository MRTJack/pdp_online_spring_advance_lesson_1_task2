package com.example.pdp_advance_task2.task2.controller;

import com.example.pdp_advance_task2.task2.dto.CategoryDTO;
import com.example.pdp_advance_task2.task2.dto.ProblemDTO;
import com.example.pdp_advance_task2.task2.dto.UserDTO;
import com.example.pdp_advance_task2.task2.eninty.Category;
import com.example.pdp_advance_task2.task2.eninty.Problem;
import com.example.pdp_advance_task2.task2.eninty.User;
import com.example.pdp_advance_task2.task2.service.CategoryService;
import com.example.pdp_advance_task2.task2.service.ProblemService;
import com.example.pdp_advance_task2.task2.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/codingbat")
public class CodingBatController {

    @Autowired
    private UserService userService;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private ProblemService problemService;

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }

    @GetMapping("/users/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable Long userId) {
        User user = userService.getUserById(userId);
        return user != null ? ResponseEntity.ok(user) : ResponseEntity.notFound().build();
    }

    @PostMapping("/add/users")
    public ResponseEntity<User> createUser(@RequestBody UserDTO userDTO) {
        User newUser = userService.createUser(userDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(newUser);
    }

    @PutMapping("/edit/users/{userId}")
    public ResponseEntity<User> updateUser(@PathVariable Long userId, @RequestBody UserDTO userDTO) {
        User updatedUser = userService.updateUser(userId, userDTO);
        return updatedUser != null ? ResponseEntity.ok(updatedUser) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delete/users/{userId}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long userId) {
        userService.deleteUser(userId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/categories")
    public List<Category> getAllCategories() {
        return categoryService.getAllCategories();
    }

    @GetMapping("/categories/{categoryId}")
    public ResponseEntity<Category> getCategoryById(@PathVariable Long categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        return category != null ? ResponseEntity.ok(category) : ResponseEntity.notFound().build();
    }

    @PostMapping("/add/categories")
    public ResponseEntity<Category> createCategory(@RequestBody CategoryDTO categoryDTO) {
        Category newCategory = categoryService.createCategory(categoryDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(newCategory);
    }

    @PutMapping("/edit/categories/{categoryId}")
    public ResponseEntity<Category> updateCategory(@PathVariable Long categoryId, @RequestBody CategoryDTO categoryDTO) {
        Category updatedCategory = categoryService.updateCategory(categoryId, categoryDTO);
        return updatedCategory != null ? ResponseEntity.ok(updatedCategory) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delete/categories/{categoryId}")
    public ResponseEntity<Void> deleteCategory(@PathVariable Long categoryId) {
        categoryService.deleteCategory(categoryId);
        return ResponseEntity.noContent().build();
    }

    // CRUD операции для проблем
    @GetMapping("/problems")
    public List<Problem> getAllProblems() {
        return problemService.getAllProblems();
    }

    @GetMapping("/problems/{problemId}")
    public ResponseEntity<Problem> getProblemById(@PathVariable Long problemId) {
        Problem problem = problemService.getProblemById(problemId);
        return problem != null ? ResponseEntity.ok(problem) : ResponseEntity.notFound().build();
    }

    @PostMapping("/add/problems")
    public ResponseEntity<Problem> createProblem(@RequestBody ProblemDTO problemDTO) {
        Problem newProblem = problemService.createProblem(problemDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(newProblem);
    }

    @PutMapping("/edit/problems/{problemId}")
    public ResponseEntity<Problem> updateProblem(@PathVariable Long problemId, @RequestBody ProblemDTO problemDTO) {
        Problem updatedProblem = problemService.updateProblem(problemId, problemDTO);
        return updatedProblem != null ? ResponseEntity.ok(updatedProblem) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/delete/problems/{problemId}")
    public ResponseEntity<Void> deleteProblem(@PathVariable Long problemId) {
        problemService.deleteProblem(problemId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/categories/{categoryId}/problems")
    public ResponseEntity<List<Problem>> getProblemsByCategory(@PathVariable Long categoryId) {
        Category category = categoryService.getCategoryById(categoryId);
        if (category != null) {
            List<Problem> problems = problemService.getProblemsByCategory(category);
            return ResponseEntity.ok(problems);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}


package com.example.pdp_advance_task2.task2.service;

import com.example.pdp_advance_task2.task2.dto.UserDTO;
import com.example.pdp_advance_task2.task2.eninty.User;
import com.example.pdp_advance_task2.task2.repo.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class UserService {
    @Autowired
    private  UserRepository userRepository;


    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User getUserById(Long userId) {
        return userRepository.findById(userId).orElse(null);
    }


    public User createUser(UserDTO userDTO) {
        User newUser = new User();
        newUser.setUsername(userDTO.getUsername());
        newUser.setPassword(userDTO.getPassword());
        return userRepository.save(newUser);
    }

    public User updateUser(Long userId, UserDTO userDTO) {
        User existingUser = getUserById(userId);
        if (existingUser == null) {
            return null;
        }
        existingUser.setUsername(userDTO.getUsername());

        if (userDTO.getPassword() != null && !userDTO.getPassword().isEmpty()) {
            String hashedPassword = hashPassword(userDTO.getPassword());
            existingUser.setPassword(hashedPassword);
        }

        return userRepository.save(existingUser);
    }

    private String hashPassword(String password) {
        return password;
    }


    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
}


